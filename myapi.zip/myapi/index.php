<html>
  <head>
    <title>Guzzle</title>
  </head>
  <body>
    <h3><?php echo $s=(isset($_REQUEST['feed_url']) ? $_REQUEST['feed_url']: ''); ?></h3>

    <form>
      <input type="text" name="feed_url">
      <input type="submit" value="Read">
    </form>

    <?php
    //composer require guzzlehttp/guzzle
    //php -S 0.0.0.0:8080
      if(isset($_REQUEST['feed_url'])){
        require './vendor/autoload.php';

       $myClient = new GuzzleHttp\Client([
          'headers' => ['User-Agent' => 'MyReader'],
          'verify' => false,
          'auth' => [
                'phillipuser',
                'P@ssw0rd'
            ]
        ]);

        $feed_response = $myClient->request('GET', $_REQUEST['feed_url']);
        echo "<pre>";
        if($feed_response->getStatusCode() == 200){

          if($feed_response->hasHeader('content-length')){
            //$contentLength = $feed_response->getHeader('content-length')[0];
            //$contentType = $feed_response->getHeader('content-Type')[0];
          }
          //echo $contentType = $feed_response->getHeader('content-Type')[0];


          $body = $feed_response->getBody();

          $data = json_decode($body);
          print_r($data);

          echo "<br>********************** Our result is **********<br>";

          //echo gettype($data->Index->data);
          if(gettype($data->Index->data) == 'object'){
            foreach($data->Index->data as $info){
              echo $info."<br>";
            }
          }else{
            foreach($data->Index->data as $a){
              echo $a->close.'<br>';
              echo $a->high.'<br>';
              echo $a->low.'<br>';
              echo $a->last.'<br>';
              echo $a->ts.'<br>';
              echo "*****************<br>";
            }
          }
          /*if data is array then it will work*/
          /*foreach($data->Index->data as $a){
            echo $a->close.'<br>';
          }*/

          /*if data is object then it will work*/
          /*foreach($data->Index->data as $info){
            echo $info."<br>";
          }*/

          //exit();

          //if return type xml...
          /*$xml = new SimpleXMLElement($body);
          print_r($xml);
          exit();

          foreach($xml->channel->item as $item){
            echo "<h3>". $item->title."</h3>";
          }*/
        }else{
          echo "status failed";
        }
      }
    ?>
  </body>
</html>
